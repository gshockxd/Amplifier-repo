<div class="row d-flex text-center">
<!--     <div class="col-sm ">
        <div class="">
            <a href="chat.php" class="btn btn-outline-danger">Beta! Chat</a>
        </div>
    </div> -->
    <div class="col-sm ">
        <div class="">
            <a href="register" class="btn btn-outline-primary">Personal</a>
        </div>
    </div>
    <div class="col-sm ">
        <div class="">   
            <a href="portfolio" class="btn btn-outline-success">Portfolio</a>
        </div>
    </div>
    <div class="col-sm ">
        <div class="">
            <a href="description" class="btn btn-outline-secondary">Description</a>
        </div>
    </div>
</div>