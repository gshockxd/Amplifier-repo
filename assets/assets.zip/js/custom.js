function switch_ui($page){
	window.location = $page;
}
